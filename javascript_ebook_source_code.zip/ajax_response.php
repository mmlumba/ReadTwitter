<?php

// Return results to the Ajax request
print "Ajax response from server.";

?>
