<?php

// OAuth tokens for single-user programming
// After you create an app you MUST copy 
// the tokens and paste them into the following lines
$consumer_key = 'CONSUMER KEY';
$consumer_secret = 'CONSUMER SECRET';
$user_token = 'USER TOKEN';
$user_secret = 'USER SECRET';

?>